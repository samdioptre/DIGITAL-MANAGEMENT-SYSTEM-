'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertCircle, ArrowLeft } from 'lucide-react'

interface QueueNumber {
  id: string
  number: number
  department: string
  timestamp: number
  status: 'waiting' | 'serving' | 'completed'
}

export default function StudentPage() {
  const [selectedDept, setSelectedDept] = useState<string | null>(null)
  const [queueNumber, setQueueNumber] = useState<QueueNumber | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const departments = [
    { id: 'finance', name: 'Finance Office', description: 'Fees, refunds, payment inquiries' },
    { id: 'admissions', name: 'Admissions Office', description: 'Enrollment, registration, transcripts' },
    { id: 'ict', name: 'ICT Support', description: 'Technical support, system issues' },
  ]

  const generateQueueNumber = async (deptId: string) => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch('/api/queue/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ department: deptId }),
      })
      const data = await response.json()
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate queue number')
      }
      
      setQueueNumber(data)
      setSelectedDept(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  if (queueNumber) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b border-border bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-2xl font-bold text-foreground">Queue Number Generated</h1>
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back Home
              </Button>
            </Link>
          </div>
        </header>

        {/* Queue Number Display */}
        <main className="container mx-auto px-4 py-12">
          <div className="max-w-md mx-auto">
            <Card className="border-2 border-primary">
              <CardHeader className="text-center">
                <CardTitle className="text-lg">Your Queue Number</CardTitle>
                <CardDescription>{queueNumber.department}</CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <div className="bg-primary text-primary-foreground rounded-lg p-12 mb-6">
                  <div className="text-7xl font-bold">{String(queueNumber.number).padStart(3, '0')}</div>
                </div>
                
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded-lg">
                    <p className="text-sm text-muted-foreground">Status</p>
                    <p className="text-lg font-semibold capitalize text-foreground">{queueNumber.status}</p>
                  </div>
                  
                  <div className="bg-muted p-4 rounded-lg">
                    <p className="text-sm text-muted-foreground">Time</p>
                    <p className="text-sm text-foreground">{new Date(queueNumber.timestamp).toLocaleTimeString()}</p>
                  </div>
                </div>

                <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg">
                  <p className="text-sm text-blue-900 dark:text-blue-100">
                    Please keep your queue number safe. You will be called when it's your turn.
                  </p>
                </div>

                <Button 
                  onClick={() => {
                    setQueueNumber(null)
                    setSelectedDept(null)
                  }}
                  className="w-full mt-8"
                  variant="outline"
                >
                  Generate Another Number
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground">Get Queue Number</h1>
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mt-0.5" />
            <div>
              <p className="font-semibold text-red-900 dark:text-red-100">Error</p>
              <p className="text-sm text-red-800 dark:text-red-200">{error}</p>
            </div>
          </div>
        )}

        <div className="max-w-2xl mx-auto">
          <h2 className="text-xl font-semibold mb-6 text-foreground">Select Department</h2>
          
          <div className="grid gap-4">
            {departments.map((dept) => (
              <Card 
                key={dept.id}
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedDept === dept.id ? 'border-primary border-2' : ''
                }`}
                onClick={() => setSelectedDept(dept.id)}
              >
                <CardHeader>
                  <CardTitle className="text-lg">{dept.name}</CardTitle>
                  <CardDescription>{dept.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>

          {selectedDept && (
            <div className="mt-8 flex gap-4">
              <Button 
                onClick={() => generateQueueNumber(selectedDept)}
                disabled={loading}
                className="flex-1"
              >
                {loading ? 'Generating...' : 'Generate Queue Number'}
              </Button>
              <Button 
                onClick={() => setSelectedDept(null)}
                variant="outline"
                disabled={loading}
              >
                Cancel
              </Button>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
