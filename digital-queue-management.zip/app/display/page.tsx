'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'

interface DisplayData {
  finance: { current: number | null; waiting: number }
  admissions: { current: number | null; waiting: number }
  ict: { current: number | null; waiting: number }
}

export default function DisplayPage() {
  const [display, setDisplay] = useState<DisplayData>({
    finance: { current: null, waiting: 0 },
    admissions: { current: null, waiting: 0 },
    ict: { current: null, waiting: 0 },
  })
  const [time, setTime] = useState<string>('')

  useEffect(() => {
    // Update time
    const updateTime = () => {
      setTime(new Date().toLocaleTimeString())
    }
    updateTime()
    const timeInterval = setInterval(updateTime, 1000)

    // Fetch display data
    const fetchDisplay = async () => {
      try {
        const response = await fetch('/api/display')
        const data = await response.json()
        if (response.ok) {
          setDisplay(data)
        }
      } catch (err) {
        console.error('Failed to fetch display data:', err)
      }
    }

    fetchDisplay()
    const interval = setInterval(fetchDisplay, 3000)

    return () => {
      clearInterval(timeInterval)
      clearInterval(interval)
    }
  }, [])

  const departments = [
    { id: 'finance', name: 'Finance Office', color: 'from-blue-500 to-blue-600', icon: '💰' },
    { id: 'admissions', name: 'Admissions Office', color: 'from-green-500 to-green-600', icon: '📋' },
    { id: 'ict', name: 'ICT Support', color: 'from-purple-500 to-purple-600', icon: '💻' },
  ]

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Back Button (hidden but accessible) */}
      <div className="absolute top-4 left-4 z-10">
        <Link href="/">
          <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
      </div>

      {/* Header */}
      <header className="bg-gradient-to-r from-primary to-primary/80 p-6 text-center border-b-4 border-primary">
        <h1 className="text-4xl font-bold mb-2">Queue Management System</h1>
        <p className="text-xl opacity-90">Meru University of Science and Technology</p>
        <p className="text-lg mt-2">{time}</p>
      </header>

      {/* Main Display */}
      <main className="flex-1 flex items-center justify-center p-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl">
          {departments.map((dept) => {
            const deptData = display[dept.id as keyof DisplayData]
            return (
              <div key={dept.id} className="flex flex-col">
                {/* Department Name */}
                <div className={`bg-gradient-to-r ${dept.color} p-6 rounded-t-2xl text-center`}>
                  <p className="text-2xl mb-2">{dept.icon}</p>
                  <h2 className="text-2xl font-bold">{dept.name}</h2>
                </div>

                {/* Current Number Display */}
                <div className="bg-gray-900 border-4 border-gray-700 p-8 rounded-b-2xl flex-1 flex flex-col items-center justify-center">
                  <p className="text-gray-400 text-lg mb-4">Now Serving</p>
                  {deptData.current !== null ? (
                    <div className="text-9xl font-bold text-white mb-8 font-mono tracking-wider">
                      {String(deptData.current).padStart(3, '0')}
                    </div>
                  ) : (
                    <div className="text-6xl font-bold text-gray-600 mb-8">---</div>
                  )}

                  {/* Queue Status */}
                  <div className="w-full border-t border-gray-700 pt-4">
                    <div className="text-center">
                      <p className="text-gray-400 text-sm mb-2">Waiting in Queue</p>
                      <p className="text-5xl font-bold text-green-400">{deptData.waiting}</p>
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-700 p-4 text-center">
        <p className="text-gray-400 text-sm">
          Please ensure you have a valid queue number before approaching the counter
        </p>
      </footer>
    </div>
  )
}
