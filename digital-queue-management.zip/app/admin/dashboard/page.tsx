'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { LogOut, TrendingUp, Clock, Users } from 'lucide-react'

interface Analytics {
  totalServed: number
  averageWaitTime: number
  currentWaiting: number
  departments: {
    finance: { served: number; avgWait: number; waiting: number }
    admissions: { served: number; avgWait: number; waiting: number }
    ict: { served: number; avgWait: number; waiting: number }
  }
}

export default function AdminDashboard() {
  const router = useRouter()
  const [analytics, setAnalytics] = useState<Analytics | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const session = localStorage.getItem('adminSession')
    if (!session) {
      router.push('/admin/login')
      return
    }

    fetchAnalytics()
    const interval = setInterval(fetchAnalytics, 10000)
    return () => clearInterval(interval)
  }, [router])

  const fetchAnalytics = async () => {
    try {
      const response = await fetch('/api/analytics')
      const data = await response.json()

      if (response.ok) {
        setAnalytics(data)
        setError(null)
      } else {
        setError(data.error || 'Failed to fetch analytics')
      }
    } catch (err) {
      console.error('Failed to fetch analytics:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('adminSession')
    router.push('/')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading analytics...</p>
      </div>
    )
  }

  const departments = [
    { id: 'finance', name: 'Finance Office', icon: '💰' },
    { id: 'admissions', name: 'Admissions Office', icon: '📋' },
    { id: 'ict', name: 'ICT Support', icon: '💻' },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Analytics Dashboard</h1>
            <p className="text-sm text-muted-foreground">Queue Performance Metrics</p>
          </div>
          <Button onClick={handleLogout} variant="destructive" size="sm">
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg">
            <p className="text-sm text-red-800 dark:text-red-200">{error}</p>
          </div>
        )}

        {/* Key Metrics */}
        <div className="grid gap-4 md:grid-cols-3 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" />
                Total Served (Today)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">{analytics?.totalServed || 0}</p>
              <p className="text-xs text-muted-foreground mt-1">Customers processed</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" />
                Avg. Wait Time
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">
                {analytics ? Math.round(analytics.averageWaitTime / 1000) : 0}s
              </p>
              <p className="text-xs text-muted-foreground mt-1">Average wait time</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" />
                Currently Waiting
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">{analytics?.currentWaiting || 0}</p>
              <p className="text-xs text-muted-foreground mt-1">In queue across all depts</p>
            </CardContent>
          </Card>
        </div>

        {/* Department Breakdown */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Department Performance</CardTitle>
            <CardDescription>Metrics for each service department</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              {departments.map((dept) => {
                const deptData = analytics?.departments[dept.id as keyof typeof analytics.departments]
                return (
                  <div key={dept.id} className="border border-border rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-4">
                      <span className="text-2xl">{dept.icon}</span>
                      <p className="font-semibold text-foreground">{dept.name}</p>
                    </div>

                    <div className="space-y-3">
                      <div className="bg-muted p-3 rounded">
                        <p className="text-xs text-muted-foreground">Served Today</p>
                        <p className="text-2xl font-bold text-foreground">{deptData?.served || 0}</p>
                      </div>

                      <div className="bg-muted p-3 rounded">
                        <p className="text-xs text-muted-foreground">Avg. Wait Time</p>
                        <p className="text-2xl font-bold text-foreground">
                          {deptData ? Math.round(deptData.avgWait / 1000) : 0}s
                        </p>
                      </div>

                      <div className="bg-muted p-3 rounded">
                        <p className="text-xs text-muted-foreground">Currently Waiting</p>
                        <p className="text-2xl font-bold text-foreground">{deptData?.waiting || 0}</p>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Performance Insights */}
        <Card>
          <CardHeader>
            <CardTitle>Performance Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                <div>
                  <p className="text-sm font-medium text-foreground">Overall System Status</p>
                  <p className="text-xs text-muted-foreground">
                    {analytics && analytics.currentWaiting === 0 
                      ? 'All departments are running smoothly with no queue' 
                      : `${analytics?.currentWaiting || 0} customers currently in queue across all departments`}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                <div>
                  <p className="text-sm font-medium text-foreground">Peak Performance</p>
                  <p className="text-xs text-muted-foreground">
                    {analytics && analytics.averageWaitTime > 120000
                      ? 'Wait times are higher than usual. Consider adding more staff.'
                      : 'System is operating within optimal parameters.'}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                <div>
                  <p className="text-sm font-medium text-foreground">Daily Throughput</p>
                  <p className="text-xs text-muted-foreground">
                    {analytics?.totalServed || 0} customers served today. {analytics?.currentWaiting || 0} still waiting.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Refresh Info */}
        <div className="mt-8 text-center text-xs text-muted-foreground">
          <p>Dashboard updates automatically every 10 seconds</p>
        </div>
      </main>
    </div>
  )
}
