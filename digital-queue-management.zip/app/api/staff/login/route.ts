import { NextRequest, NextResponse } from 'next/server'

// Demo staff credentials (in production, use a database with hashed passwords)
const STAFF_CREDENTIALS = {
  STF001: 'demo123',
  STF002: 'demo123',
  STF003: 'demo123',
}

export async function POST(request: NextRequest) {
  try {
    const { staffId, password, department, window } = await request.json()

    if (!staffId || !password || !department || !window) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Validate credentials
    if (STAFF_CREDENTIALS[staffId as keyof typeof STAFF_CREDENTIALS] !== password) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      )
    }

    // Return session data
    const sessionData = {
      staffId,
      department,
      window,
      loginTime: Date.now(),
    }

    return NextResponse.json(sessionData)
  } catch (error) {
    console.error('Staff login error:', error)
    return NextResponse.json(
      { error: 'Login failed' },
      { status: 500 }
    )
  }
}
