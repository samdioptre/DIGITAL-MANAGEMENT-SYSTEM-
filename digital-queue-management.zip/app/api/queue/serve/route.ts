import { NextRequest, NextResponse } from 'next/server'

const getStorage = () => {
  if (typeof globalThis !== 'undefined') {
    if (!(globalThis as any).__queueStorage) {
      (globalThis as any).__queueStorage = []
    }
    return (globalThis as any).__queueStorage
  }
  return []
}

export async function POST(request: NextRequest) {
  try {
    const { queueId, staffId, window } = await request.json()

    if (!queueId || !staffId || !window) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const storage = getStorage()
    const queueItem = storage.find((item: any) => item.id === queueId)

    if (!queueItem) {
      return NextResponse.json(
        { error: 'Queue item not found' },
        { status: 404 }
      )
    }

    // Mark any previously serving item as completed first
    storage.forEach((item: any) => {
      if (item.status === 'serving' && item.id !== queueId) {
        item.status = 'completed'
        item.serviceEndTime = Date.now()
      }
    })

    // Update the queue item
    queueItem.status = 'serving'
    queueItem.serviceStartTime = Date.now()

    return NextResponse.json(queueItem)
  } catch (error) {
    console.error('Serve queue error:', error)
    return NextResponse.json(
      { error: 'Failed to serve customer' },
      { status: 500 }
    )
  }
}
