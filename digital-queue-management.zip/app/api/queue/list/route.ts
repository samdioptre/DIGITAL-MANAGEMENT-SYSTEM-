import { NextRequest, NextResponse } from 'next/server'

// Import the shared storage from the generate route
// In a real app, this would come from a database
let queueStorage: Array<{
  id: string
  number: number
  department: string
  timestamp: number
  status: 'waiting' | 'serving' | 'completed'
  serviceTime?: number
}> = []

// Store it globally for this request handler
const getStorage = () => {
  if (typeof globalThis !== 'undefined') {
    if (!(globalThis as any).__queueStorage) {
      (globalThis as any).__queueStorage = []
    }
    return (globalThis as any).__queueStorage
  }
  return queueStorage
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const department = searchParams.get('department')

    if (!department) {
      return NextResponse.json(
        { error: 'Department parameter is required' },
        { status: 400 }
      )
    }

    const storage = getStorage()
    const departmentQueue = storage.filter(
      (item) => item.department === department
    )

    // Sort by status (waiting first, then serving, then completed)
    // Within each status, sort by timestamp
    const sortedQueue = departmentQueue.sort((a, b) => {
      const statusOrder = { waiting: 0, serving: 1, completed: 2 }
      const aOrder = statusOrder[a.status]
      const bOrder = statusOrder[b.status]

      if (aOrder !== bOrder) {
        return aOrder - bOrder
      }
      return a.timestamp - b.timestamp
    })

    return NextResponse.json({ queue: sortedQueue })
  } catch (error) {
    console.error('Queue list error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch queue' },
      { status: 500 }
    )
  }
}
