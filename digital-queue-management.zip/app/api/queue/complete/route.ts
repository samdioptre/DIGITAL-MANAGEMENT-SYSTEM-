import { NextRequest, NextResponse } from 'next/server'

const getStorage = () => {
  if (typeof globalThis !== 'undefined') {
    if (!(globalThis as any).__queueStorage) {
      (globalThis as any).__queueStorage = []
    }
    return (globalThis as any).__queueStorage
  }
  return []
}

export async function POST(request: NextRequest) {
  try {
    const { queueId, serviceTime } = await request.json()

    if (!queueId) {
      return NextResponse.json(
        { error: 'Queue ID is required' },
        { status: 400 }
      )
    }

    const storage = getStorage()
    const queueItem = storage.find((item: any) => item.id === queueId)

    if (!queueItem) {
      return NextResponse.json(
        { error: 'Queue item not found' },
        { status: 404 }
      )
    }

    // Mark as completed
    queueItem.status = 'completed'
    queueItem.serviceEndTime = Date.now()
    queueItem.serviceTime = serviceTime

    return NextResponse.json(queueItem)
  } catch (error) {
    console.error('Complete service error:', error)
    return NextResponse.json(
      { error: 'Failed to complete service' },
      { status: 500 }
    )
  }
}
