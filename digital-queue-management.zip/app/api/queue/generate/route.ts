import { NextRequest, NextResponse } from 'next/server'

// In-memory queue storage (in production, use a database)
interface QueueEntry {
  id: string
  number: number
  department: string
  timestamp: number
  status: 'waiting' | 'serving' | 'completed'
  serviceStartTime?: number
  serviceEndTime?: number
  serviceTime?: number
}

// Counter for queue numbers per department
const queueCounters: Record<string, number> = {
  finance: 0,
  admissions: 0,
  ict: 0,
}

const queueStorage: QueueEntry[] = []

export async function POST(request: NextRequest) {
  try {
    const { department } = await request.json()

    if (!department || !['finance', 'admissions', 'ict'].includes(department)) {
      return NextResponse.json(
        { error: 'Invalid department' },
        { status: 400 }
      )
    }

    // Generate queue number
    queueCounters[department]++
    const queueNumber = queueCounters[department]

    const entry: QueueEntry = {
      id: `${department}-${queueNumber}-${Date.now()}`,
      number: queueNumber,
      department,
      timestamp: Date.now(),
      status: 'waiting',
    }

    queueStorage.push(entry)

    return NextResponse.json(entry)
  } catch (error) {
    console.error('Queue generation error:', error)
    return NextResponse.json(
      { error: 'Failed to generate queue number' },
      { status: 500 }
    )
  }
}

// Export for use in other API routes
export { queueStorage, queueCounters }
