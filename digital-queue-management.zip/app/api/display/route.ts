import { NextRequest, NextResponse } from 'next/server'

const getStorage = () => {
  if (typeof globalThis !== 'undefined') {
    if (!(globalThis as any).__queueStorage) {
      (globalThis as any).__queueStorage = []
    }
    return (globalThis as any).__queueStorage
  }
  return []
}

export async function GET(request: NextRequest) {
  try {
    const storage = getStorage()

    const displayData = {
      finance: {
        current: null as number | null,
        waiting: 0,
      },
      admissions: {
        current: null as number | null,
        waiting: 0,
      },
      ict: {
        current: null as number | null,
        waiting: 0,
      },
    }

    // Process each department
    ;(['finance', 'admissions', 'ict'] as const).forEach((dept) => {
      const deptQueue = storage.filter((item: any) => item.department === dept)

      // Find currently serving
      const serving = deptQueue.find((item: any) => item.status === 'serving')
      if (serving) {
        displayData[dept].current = serving.number
      }

      // Count waiting
      const waiting = deptQueue.filter((item: any) => item.status === 'waiting')
      displayData[dept].waiting = waiting.length
    })

    return NextResponse.json(displayData)
  } catch (error) {
    console.error('Display error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch display data' },
      { status: 500 }
    )
  }
}
