import { NextRequest, NextResponse } from 'next/server'

// Demo admin credentials (in production, use a database with hashed passwords)
const ADMIN_CREDENTIALS = {
  admin: 'demo123',
  manager: 'demo123',
}

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json()

    if (!username || !password) {
      return NextResponse.json(
        { error: 'Missing username or password' },
        { status: 400 }
      )
    }

    // Validate credentials
    if (ADMIN_CREDENTIALS[username as keyof typeof ADMIN_CREDENTIALS] !== password) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      )
    }

    // Return session data
    const sessionData = {
      username,
      role: 'admin',
      loginTime: Date.now(),
    }

    return NextResponse.json(sessionData)
  } catch (error) {
    console.error('Admin login error:', error)
    return NextResponse.json(
      { error: 'Login failed' },
      { status: 500 }
    )
  }
}
