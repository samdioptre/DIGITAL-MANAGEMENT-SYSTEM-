import { NextRequest, NextResponse } from 'next/server'

const getStorage = () => {
  if (typeof globalThis !== 'undefined') {
    if (!(globalThis as any).__queueStorage) {
      (globalThis as any).__queueStorage = []
    }
    return (globalThis as any).__queueStorage
  }
  return []
}

export async function GET(request: NextRequest) {
  try {
    const storage = getStorage()

    // Calculate overall metrics
    const completed = storage.filter((item: any) => item.status === 'completed')
    const serving = storage.filter((item: any) => item.status === 'serving')
    const waiting = storage.filter((item: any) => item.status === 'waiting')

    // Calculate average wait times
    const avgWaitTime = completed.length > 0
      ? completed.reduce((sum: number, item: any) => {
          const waitTime = (item.serviceStartTime || Date.now()) - item.timestamp
          return sum + waitTime
        }, 0) / completed.length
      : 0

    // Department-specific analytics
    const departments = {
      finance: calculateDeptMetrics('finance'),
      admissions: calculateDeptMetrics('admissions'),
      ict: calculateDeptMetrics('ict'),
    }

    function calculateDeptMetrics(dept: string) {
      const deptQueue = storage.filter((item: any) => item.department === dept)
      const deptCompleted = deptQueue.filter((item: any) => item.status === 'completed')
      const deptWaiting = deptQueue.filter((item: any) => item.status === 'waiting')

      const deptAvgWait = deptCompleted.length > 0
        ? deptCompleted.reduce((sum: number, item: any) => {
            const waitTime = (item.serviceStartTime || Date.now()) - item.timestamp
            return sum + waitTime
          }, 0) / deptCompleted.length
        : 0

      return {
        served: deptCompleted.length,
        avgWait: deptAvgWait,
        waiting: deptWaiting.length,
      }
    }

    return NextResponse.json({
      totalServed: completed.length,
      averageWaitTime: avgWaitTime,
      currentWaiting: waiting.length,
      departments,
    })
  } catch (error) {
    console.error('Analytics error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch analytics' },
      { status: 500 }
    )
  }
}
