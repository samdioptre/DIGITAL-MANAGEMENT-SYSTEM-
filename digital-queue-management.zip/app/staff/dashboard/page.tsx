'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertCircle, LogOut, Clock } from 'lucide-react'

interface StaffSession {
  staffId: string
  department: string
  window: string
}

interface QueueItem {
  id: string
  number: number
  department: string
  status: 'waiting' | 'serving' | 'completed'
  timestamp: number
}

export default function StaffDashboard() {
  const router = useRouter()
  const [session, setSession] = useState<StaffSession | null>(null)
  const [queue, setQueue] = useState<QueueItem[]>([])
  const [currentServing, setCurrentServing] = useState<QueueItem | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [serviceStartTime, setServiceStartTime] = useState<number | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check session
    const storedSession = localStorage.getItem('staffSession')
    if (!storedSession) {
      router.push('/staff/login')
      return
    }

    const parsedSession = JSON.parse(storedSession) as StaffSession
    setSession(parsedSession)

    // Load queue
    fetchQueue()

    const interval = setInterval(fetchQueue, 5000)
    return () => clearInterval(interval)
  }, [router])

  const fetchQueue = async () => {
    try {
      const storedSession = localStorage.getItem('staffSession')
      if (!storedSession) return

      const { department } = JSON.parse(storedSession)
      const response = await fetch(`/api/queue/list?department=${department}`)
      const data = await response.json()

      if (response.ok) {
        setQueue(data.queue || [])
        const serving = data.queue?.find((q: QueueItem) => q.status === 'serving')
        if (serving && !currentServing) {
          setCurrentServing(serving)
        }
      }
    } catch (err) {
      console.error('Failed to fetch queue:', err)
    } finally {
      setLoading(false)
    }
  }

  const serveNext = async () => {
    try {
      const waitingQueue = queue.filter((q) => q.status === 'waiting')
      if (waitingQueue.length === 0) {
        setError('No more customers in queue')
        return
      }

      const nextCustomer = waitingQueue[0]
      const response = await fetch('/api/queue/serve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          queueId: nextCustomer.id,
          staffId: session?.staffId,
          window: session?.window,
        }),
      })

      const data = await response.json()
      if (response.ok) {
        setCurrentServing(data)
        setServiceStartTime(Date.now())
        setError(null)
        await fetchQueue()
      } else {
        setError(data.error || 'Failed to serve customer')
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    }
  }

  const completeService = async () => {
    if (!currentServing) return

    try {
      const response = await fetch('/api/queue/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          queueId: currentServing.id,
          serviceTime: serviceStartTime ? Date.now() - serviceStartTime : 0,
        }),
      })

      const data = await response.json()
      if (response.ok) {
        setCurrentServing(null)
        setServiceStartTime(null)
        setError(null)
        await fetchQueue()
      } else {
        setError(data.error || 'Failed to complete service')
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('staffSession')
    router.push('/')
  }

  if (!session) {
    return null
  }

  const waitingCount = queue.filter((q) => q.status === 'waiting').length

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Service Dashboard</h1>
            <p className="text-sm text-muted-foreground">
              {session.department} • Window {session.window} • Staff ID: {session.staffId}
            </p>
          </div>
          <Button onClick={handleLogout} variant="destructive" size="sm">
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mt-0.5 flex-shrink-0" />
            <p className="text-sm text-red-800 dark:text-red-200">{error}</p>
          </div>
        )}

        <div className="grid gap-6 lg:grid-cols-3 mb-8">
          {/* Current Serving Card */}
          <Card className="lg:col-span-2 border-2 border-primary">
            <CardHeader>
              <CardTitle>Currently Serving</CardTitle>
            </CardHeader>
            <CardContent>
              {currentServing ? (
                <div className="space-y-4">
                  <div className="bg-primary text-primary-foreground rounded-lg p-8">
                    <div className="text-5xl font-bold text-center">
                      {String(currentServing.number).padStart(3, '0')}
                    </div>
                  </div>

                  {serviceStartTime && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      Service Time:{' '}
                      {Math.floor((Date.now() - serviceStartTime) / 1000)}s
                    </div>
                  )}

                  <Button onClick={completeService} className="w-full">
                    Mark as Completed
                  </Button>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">No customer being served</p>
                  <Button onClick={serveNext} disabled={waitingCount === 0} size="lg">
                    {waitingCount > 0 ? `Serve Next (${waitingCount} waiting)` : 'No customers waiting'}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Queue Statistics */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Queue Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">Waiting</p>
                <p className="text-3xl font-bold text-foreground">{waitingCount}</p>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">Completed Today</p>
                <p className="text-3xl font-bold text-foreground">
                  {queue.filter((q) => q.status === 'completed').length}
                </p>
              </div>

              {currentServing && (
                <Button onClick={serveNext} variant="outline" className="w-full bg-transparent">
                  Skip & Serve Next
                </Button>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Queue List */}
        <Card>
          <CardHeader>
            <CardTitle>Waiting Queue</CardTitle>
            <CardDescription>Next customers in line</CardDescription>
          </CardHeader>
          <CardContent>
            {queue.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No customers in queue</p>
            ) : (
              <div className="space-y-2">
                {queue
                  .filter((q) => q.status === 'waiting')
                  .map((item, index) => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div>
                        <p className="font-semibold">#{String(item.number).padStart(3, '0')}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(item.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Position: {index + 1}</p>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
